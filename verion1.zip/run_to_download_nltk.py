
import nltk
nltk.download('vader_lexicon')
nltk.download('wordnet')