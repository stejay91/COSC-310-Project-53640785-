# Group-19

This repository is for our chat support bot. There are 4 main classes (returns, refund, test, main). Returns and refund classes are self-explanatory, as they contain the return and refund section respectively. The test class is a Q&A section for any questions the user may have. The main class is the main loop where all the code is combined. In order to run the code, run the main file. (For return section, valid orderid is any integer 1-3).
